
export default {
    dummyData: [
        {
            noteTitle: "Bookmarks",
            noteContent: {
                title: "Go to Youtube",
                value: "https://youtube.com",
            },
            type: "URL",
        },
        {
            noteTitle: "Text Note",
            noteContent: {
                value: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Enim, voluptate. Velit ipsa aut labore, reiciendis quae est pariatur accusamus neque similique necessitatibus. Dolor dolorum temporibus aut eius quidem assumenda delectus.",
            },
            type: "TEXT_NOTE",
        }, 
        {
            noteTitle: "Todo List",
            noteContent: {
                value: [
                    {
                        isChecked: false,
                        text: "Note 1 content",
                    },
                    {
                        isChecked: false,
                        text: "Note 1 content",
                    },
                    {
                        isChecked: true,
                        text: "Note 1 content",
                    },
                ],
            },
            type: "CHECKBOX_LIST",
        },
        {
            noteTitle: "Text Note",
            noteContent: {
                value: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Enim, voluptate. Velit ipsa aut labore, reiciendis quae est pariatur accusamus neque similique necessitatibus. Dolor dolorum temporibus aut eius quidem assumenda delectus.",
            },
            type: "TEXT_NOTE",
        },
        {
            noteTitle: "Text Note",
            noteContent: {
                value: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Enim, voluptate. Velit ipsa aut labore, reiciendis quae est pariatur accusamus neque similique necessitatibus. Dolor dolorum temporibus aut eius quidem assumenda delectus.",
            },
            type: "TEXT_NOTE",
        },
        {
            noteTitle: "Text Note",
            noteContent: {
                value: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Enim, voluptate. Velit ipsa aut labore, reiciendis quae est pariatur accusamus neque similique necessitatibus. Dolor dolorum temporibus aut eius quidem assumenda delectus.",
            },
            type: "TEXT_NOTE",
        },
        {
            noteTitle: "Text Note",
            noteContent: {
                value: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Enim, voluptate. Velit ipsa aut labore, reiciendis quae est pariatur accusamus neque similique necessitatibus. Dolor dolorum temporibus aut eius quidem assumenda delectus.",
            },
            type: "TEXT_NOTE",
        },
        {
            noteTitle: "Text Note",
            noteContent: {
                value: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Enim, voluptate. Velit ipsa aut labore, reiciendis quae est pariatur accusamus neque similique necessitatibus. Dolor dolorum temporibus aut eius quidem assumenda delectus.",
            },
            type: "TEXT_NOTE",
        },
        {
            noteTitle: "Text Note",
            noteContent: {
                value: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Enim, voluptate. Velit ipsa aut labore, reiciendis quae est pariatur accusamus neque similique necessitatibus. Dolor dolorum temporibus aut eius quidem assumenda delectus.",
            },
            type: "TEXT_NOTE",
        },
        {
            noteTitle: "Text Note",
            noteContent: {
                value: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Enim, voluptate. Velit ipsa aut labore, reiciendis quae est pariatur accusamus neque similique necessitatibus. Dolor dolorum temporibus aut eius quidem assumenda delectus.",
            },
            type: "TEXT_NOTE",
        },
        {
            noteTitle: "Text Note",
            noteContent: {
                value: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Enim, voluptate. Velit ipsa aut labore, reiciendis quae est pariatur accusamus neque similique necessitatibus. Dolor dolorum temporibus aut eius quidem assumenda delectus.",
            },
            type: "TEXT_NOTE",
        },
        {
            noteTitle: "Text Note",
            noteContent: {
                value: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Enim, voluptate. Velit ipsa aut labore, reiciendis quae est pariatur accusamus neque similique necessitatibus. Dolor dolorum temporibus aut eius quidem assumenda delectus.",
            },
            type: "TEXT_NOTE",
        },
        {
            noteTitle: "Text Note",
            noteContent: {
                value: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Enim, voluptate. Velit ipsa aut labore, reiciendis quae est pariatur accusamus neque similique necessitatibus. Dolor dolorum temporibus aut eius quidem assumenda delectus.",
            },
            type: "TEXT_NOTE",
        },
        {
            noteTitle: "Text Note",
            noteContent: {
                value: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Enim, voluptate. Velit ipsa aut labore, reiciendis quae est pariatur accusamus neque similique necessitatibus. Dolor dolorum temporibus aut eius quidem assumenda delectus.",
            },
            type: "TEXT_NOTE",
        },
        {
            noteTitle: "Text Note",
            noteContent: {
                value: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Enim, voluptate. Velit ipsa aut labore, reiciendis quae est pariatur accusamus neque similique necessitatibus. Dolor dolorum temporibus aut eius quidem assumenda delectus.",
            },
            type: "TEXT_NOTE",
        },

    ]
}